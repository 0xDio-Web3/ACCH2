package com.example.contador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContadorApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContadorApplication.class, args);
    }
}